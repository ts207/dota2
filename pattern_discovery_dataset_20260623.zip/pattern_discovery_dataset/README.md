# Pattern Discovery Dataset

Use this for Tier 2/Tier 3 strategy research and pattern mining. It contains game-state snapshots joined to OpenDota outcomes and derived leader fields.

Do not use this alone for executable ROI. Validate any rule on the clean executable dataset.
