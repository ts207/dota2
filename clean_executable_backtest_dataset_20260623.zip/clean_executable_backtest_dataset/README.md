# Clean Executable Backtest Dataset

Primary file: `clean_backtest_side_snapshots.parquet`.

Each row is one game snapshot for one tradeable side/token. It includes mapped market identity, nearest prior top-of-book, and side settlement outcome.

Use `book_best_ask` as entry cost for buying that side. `settled_win` is the hold-to-settlement result for that token.

Included label buckets: `MAP_WINNER`, `MATCH_WINNER_BO1`, and `MATCH_WINNER_GAME3_PROXY`.
